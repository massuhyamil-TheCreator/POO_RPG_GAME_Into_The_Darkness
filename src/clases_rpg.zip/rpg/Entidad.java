public abstract class Entidad {

    private String nombre;
    private String categoria;
    private int puntosDeSalud;
    private int puntosDeSaludMaximos;
    private int recurso;
    private int recursoMaximo;
    private int velocidad;
    private int precision;
    private int nivel;
    private int experiencia;
    private int ataqueFisico;
    private int ataqueMagico;
    private int defensaFisica;
    private int defensaMagica;

    public Entidad(String nombre, String categoria, int puntosDeSalud, int puntosDeSaludMaximos, int recurso, int recursoMaximo, int velocidad, int precision, int nivel, int experiencia, int ataqueFisico, int ataqueMagico, int defensaFisica, int defensaMagica) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.puntosDeSalud = puntosDeSalud;
        this.puntosDeSaludMaximos = puntosDeSaludMaximos;
        this.recurso = recurso;
        this.recursoMaximo = recursoMaximo;
        this.velocidad = velocidad;
        this.precision = precision;
        this.nivel = nivel;
        this.experiencia = experiencia;
        this.ataqueFisico = ataqueFisico;
        this.ataqueMagico = ataqueMagico;
        this.defensaFisica = defensaFisica;
        this.defensaMagica = defensaMagica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getPuntosDeSalud() {
        return puntosDeSalud;
    }

    public void setPuntosDeSalud(int puntosDeSalud) {
        this.puntosDeSalud = puntosDeSalud;
    }

    public int getPuntosDeSaludMaximos() {
        return puntosDeSaludMaximos;
    }

    public void setPuntosDeSaludMaximos(int puntosDeSaludMaximos) {
        this.puntosDeSaludMaximos = puntosDeSaludMaximos;
    }

    public int getRecurso() {
        return recurso;
    }

    public void setRecurso(int recurso) {
        this.recurso = recurso;
    }

    public int getRecursoMaximo() {
        return recursoMaximo;
    }

    public void setRecursoMaximo(int recursoMaximo) {
        this.recursoMaximo = recursoMaximo;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }

    public int getAtaqueFisico() {
        return ataqueFisico;
    }

    public void setAtaqueFisico(int ataqueFisico) {
        this.ataqueFisico = ataqueFisico;
    }

    public int getAtaqueMagico() {
        return ataqueMagico;
    }

    public void setAtaqueMagico(int ataqueMagico) {
        this.ataqueMagico = ataqueMagico;
    }

    public int getDefensaFisica() {
        return defensaFisica;
    }

    public void setDefensaFisica(int defensaFisica) {
        this.defensaFisica = defensaFisica;
    }

    public int getDefensaMagica() {
        return defensaMagica;
    }

    public void setDefensaMagica(int defensaMagica) {
        this.defensaMagica = defensaMagica;
    }
}
