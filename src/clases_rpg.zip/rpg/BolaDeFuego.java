public class BolaDeFuego implements Habilidad {

    public BolaDeFuego() {
    }
}
