# Correccion de la Fase B: que se cambio y por que

Compila con 0 errores. Verificaciones hechas (sin abrir ventanas reales):
- 600 partidas simuladas sobre la logica (peleas con habilidades, items, invocaciones, guardar y cargar): 0 excepciones.
- Las pantallas reales (menu, partidas, seleccion, mapa, preparacion, combate y final) se cargaron en modo sin ventana y se
  jugaron 3 peleas completas tocando sus botones: sin errores de logica. Se revisaron capturas del mapa y del combate.
- NO se probo: el mouse sobre la ventana real, los dialogos (JOptionPane) ni el fundido entre pantallas. Eso hay que mirarlo a mano.

## Observaciones de la devolucion -> cambio

| Observacion | Cambio | Donde | Principio |
|---|---|---|---|
| La interfaz accede y modifica directamente el modelo | Las pantallas solo importan dto y controlador. Ninguna clase de ui importa algo del modelo | ui, controlador, dto | MVC / Controller |
| Las pantallas ejecutan acciones de negocio directamente (batalla.defender(), partida.avanzarA()...) | Ahora piden la accion al controlador: ControladorCombate.defender(), ControladorJuego.avanzarA(idNodo)... | ControladorJuego, ControladorCombate | Controller |
| Algunas pantallas crean objetos del modelo (new Partida, CreadorDePersonajes) | Lo hace el controlador: ControladorJuego.nuevaPartida(ranura, clases) | PantallaSeleccionPersonajes | Controller / Bajo acoplamiento |
| Las reglas estaban en la pantalla (a quien se puede atacar, si alcanza el mana) | Pasaron al controlador: objetivosDe(), motivoNoUsable(), motivoSinObjetos() | ControladorCombate | Information Expert |
| instanceof y switch por tipo | Polimorfismo: esAliado(), unirseA(), Item.guardarEn(), Personaje.alAvanzarNodo(), Objetivo.resolver(), EventoDeNodo | entidades, objetos, partida | Polimorfismo / Open-Closed |
| Batalla y Partida con demasiadas responsabilidades | OrdenDeTurnos (+ComparadorDeTurnos), Recompensas, eventos de nodo. Batalla 362 -> 301 lineas, Partida 288 -> 179 | combate, partida | Responsabilidad unica / Alta cohesion |
| Persistencia acoplada a clases concretas | getClase()/getTipo()/id + Map de fabricas. Guardado dividido en GuardadoDePartidas y SerializadorDePartida | partida | Bajo acoplamiento |

## Que se recorto
Version de consola, herrero, tesoros, eventos, armaduras y un catalogo de armas/armaduras por clase que nadie usaba, y una pantalla
de seleccion de personajes vieja que nadie usaba. Nodos que quedan: batalla, batalla elite, jefe y fogata. Objetos: armas y consumibles.

## Para actualizar el documento y los diagramas (tienen que coincidir con el codigo)
Clases nuevas o que cambiaron de rol:
- Vista: Navegador (interfaz), VentanaPrincipal, Pantalla* (ahora usan DTOs).
- Controlador: ControladorJuego, ControladorCombate, Conversor (arma los DTOs).
- DTO: EntidadDTO, HabilidadDTO, ItemDTO, NodoDTO, MapaDTO, PartidaDTO, CombateDTO, SeleccionDeObjetivo, ResumenDeBatalla, ResultadoFinal, EstadoDelJuego, EstadoDelCombate.
- Modelo: Batalla, OrdenDeTurnos, ComparadorDeTurnos, Recompensas, Partida, EventoDeNodo (EventoBatalla, EventoFogata),
  GuardadoDePartidas, SerializadorDePartida, CreadorDePersonajes, GeneradorDeEncuentros, Objetivo (enum con comportamiento).
- En el diagrama anterior se usaba ControladorDeTurno y Party/GrupoDeCombate: en el codigo son Batalla/OrdenDeTurnos y PartyAliada/PartyEnemiga.

Secuencias para dibujar (operaciones reales):
1. Defender: Jugador -> PantallaCombate -> ControladorCombate.defender() -> Batalla.defender() -> Entidad.aplicarEfecto(Defensa)
   -> Batalla.terminarTurno() -> OrdenDeTurnos.siguiente() -> (vuelve) ControladorCombate.getEstado() -> CombateDTO -> PantallaCombate.
2. Entrar a una pelea: Jugador -> PantallaMapa -> ControladorJuego.avanzarA(id) -> Partida.avanzarA() -> EventoBatalla.entrar()
   -> GeneradorDeEncuentros.batalla() -> Partida.prepararBatalla().
3. Guardar: PantallaMapa -> MenuDePausa -> ControladorJuego.guardar() -> GuardadoDePartidas.guardar() -> SerializadorDePartida.capturar().

## Para probar a mano
1. Menu > Jugar > ranura vacia > elegir 3 personajes > Continuar.
2. Mapa: elegir un nodo dorado. Se ve el inventario y el tooltip de cada personaje.
3. Preparacion: cambiar arma, repartir pociones, "Siguiente" y "A pelear".
4. Combate: Atacar (elegir enemigo), Defender, Habilidad (con objetivo), Objeto (sobre un aliado), Pasar, Pausa (Esc).
5. Fogata: descansar. Guardar y salir, volver a entrar y "Continuar".
6. Perder una pelea: aparece Game Over y "Ultimo guardado" carga la ranura.
